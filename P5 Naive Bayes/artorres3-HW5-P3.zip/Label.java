/**
 * An enumeration representing the two classes of interest.
 * <p>
 * DO NOT MODIFY
 */
public enum Label {
    NEGATIVE, POSITIVE
}
